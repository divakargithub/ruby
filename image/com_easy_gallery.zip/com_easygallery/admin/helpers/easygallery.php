<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

class JHTMLEasygallery
{
	/**
	 * Displays the avail state as an clickable button
	 */
	function approve( &$row, $i, $actionA = 'Reject image', $actionR = 'Approve image', $altA = 'Approve', $altR = 'Rejected', $imgY = 'tick.png', $imgX = 'publish_x.png', $prefix='')
	{
		$img 	= (($row->approve == 'Y') ? $imgY : $imgX);
		$task 	= (($row->approve == 'Y') ? 'reject' : 'approve');
		$alt 	= (($row->approve == 'Y') ? JText::_($altA) : JText::_($altR));
		$action = (($row->approve == 'Y') ? JText::_($actionA) : JText::_($actionR));

		$href = '<a href="javascript:void(0);" onclick="return listItemTask(\'cb'. $i .'\',\''. $prefix.$task .'\')" title="'. $action .'"><img src="images/'. $img .'" border="0" alt="'. $alt .'" /></a>';

		return $href;
	}
}