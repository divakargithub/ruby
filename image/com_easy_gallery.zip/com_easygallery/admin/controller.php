<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.controller' );

/**
 * Easygallery Controller
 *
 * @package Joomla
 * @subpackage Easygallery
 */
class EasygalleryController extends JController {
    /**
     * Constructor
     * @access private
     * @subpackage Easygallery
     */
    function __construct() {

        //Get View
        if(JRequest::getCmd('view') == '') {
            JRequest::setVar('view', 'default');
        }

		$this->item_type = 'Default';

        parent::__construct();
    }
}
?>