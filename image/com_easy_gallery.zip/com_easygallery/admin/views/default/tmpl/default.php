<?php
defined('_JEXEC') or die('Restricted access');

JToolBarHelper::title(JText::_('EasyGallery'), 'generic.png');
JToolBarHelper::preferences('com_easygallery', 500);

?>
EasyGallery component