<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/


defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class EasygalleryViewImage extends JView {

	function display($tpl = null) {
		$image =& $this->get('Data');
		$isNew = ($image->imageid < 1);

		$text = $isNew ? JText::_('New') : JText::_('Edit');
		JToolBarHelper::title(   JText::_( 'Image' ).': <small><small>[ ' . $text.' ]</small></small>' );

		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('image', $image);

		$editor = & JFactory::getEditor();
		$this->assignRef('editor', $editor);

		parent::display($tpl);
	}
}