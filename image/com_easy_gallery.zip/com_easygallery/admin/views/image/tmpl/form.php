<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm" id="adminForm" ENCTYPE="multipart/form-data">
<div class="col100">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Details' ); ?></legend>

		<table class="adminform">
		<tr>
			<td width="100" align="left">
				<label for="image">
					<?php echo JText::_('Image'); ?>:
				</label>
			</td>
			<td>
				<?php 
				if ($this->image->image_path) {
					echo '<img src="' . COM_EASYGALLERY_IMAGE_BASEURL . $this->image->filename . '" width="80" /><br />';
				}
				?>
				<input class="text_area" type="file" name="image_data" id="image" size="32" maxlength="250" />
			</td>
		</tr>
		<tr>
			<td width="100" align="left">
				<label for="alt">
					<?php echo JText::_('Alt'); ?>:
				</label>
			</td>
			<td>
				<input class="text" type="text" name="alt" id="alt" size="64" maxlength="250" value="<?php echo $this->image->alt;?>" />
			</td>
		</tr>
		<tr>
			<td width="100" align="right">
				<label for="descr">
					<?php echo JText::_('Description'); ?>:
				</label>
			</td>
			<td>
				<?php echo $this->editor->display('descr',  $this->image->descr, '100%', '200', '75', '20', array('pagebreak', 'readmore')) ; ?>
			</td>
		</tr>
		<tr>
			<td width="100" align="left">
				<label for="approve">
					<?php echo JText::_('Approve'); ?>:
				</label>
			</td>
			<td>
				<input class="text" type="checkbox" name="approve" id="approve" value="Y" <?php if ($this->image->approve == 'Y') {echo 'checked="checked"';} ?> />
			</td>
		</tr>
		<tr>
			<td width="100" align="left">
				<label for="orderby">
					<?php echo JText::_('Order by'); ?>:
				</label>
			</td>
			<td>
				<input class="text" type="text" name="orderby" id="orderby" size="10" maxlength="4" value="<?php echo $this->image->orderby; ?>" />
			</td>
		</tr>
		</table>
	</fieldset>
</div>
<div class="clr"></div>
<input type="hidden" name="option" value="com_easygallery" />
<input type="hidden" name="imageid" value="<?php echo $this->image->imageid; ?>" />
<input type="hidden" name="task" value="upload" />
<input type="hidden" name="controller" value="images" />
</form>