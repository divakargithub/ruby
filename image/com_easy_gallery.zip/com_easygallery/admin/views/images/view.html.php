<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class EasygalleryViewImages extends JView {
	function display($tpl = null) {
		JToolbarHelper::custom('approve', 'apply.png', 'apply.png', 'Approve');
		JToolbarHelper::custom('reject', 'cancel.png', 'cancel.png', 'Reject');

		JToolbarHelper::spacer();
		JToolbarHelper::divider();
		JToolbarHelper::spacer();


		JToolBarHelper::title(JText::_('Images Manager'), 'generic.png' );
		JToolBarHelper::deleteList();
		#JToolBarHelper::editListX();
		JToolBarHelper::addNewX('edit');

		// Get data from the model
		$items = & $this->get('Data');

		$this->assignRef('items', $items);

		parent::display($tpl);
	}
}