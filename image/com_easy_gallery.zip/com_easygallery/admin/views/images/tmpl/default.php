<?php defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( '#' ); ?>
			</th>
			<th width="5">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
			</th>			
			<th width="10%">
				<?php echo JText::_('Image'); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_('Image path'); ?>
			</th>
			<th width="20%">
				<?php echo JText::_('Alt'); ?>
			</th>
			<th width="80%">
				<?php echo JText::_('Description'); ?>
			</th>
			<th width="5">
				<?php echo JText::_('Approve'); ?>
			</th>
			<th width="5" nowrap="nowrap">
				<?php echo JText::_('Order by'); ?>
				<?php echo JHTML::_('grid.order', $this->items); ?>
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		$row = &$this->items[$i];
		$checked = JHTML::_('grid.id',   $i, $row->imageid );
		$approve = JHTML::_('easygallery.approve', $row, $i);
		$link = JRoute::_( 'index.php?option=com_easygallery&controller=images&task=edit&imageid[]='. $row->imageid );
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->imageid; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><img src="<?php echo COM_EASYGALLERY_IMAGE_BASEURL . $row->filename; ?>" width="40" height="40" /></a>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->filename; ?></a>
				<br /><?php echo $row->image_x . ' x ' .$row->image_y . '<br />' . $row->image_size . 'byte'; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->alt; ?></a>
			</td>
			<td>
				<?php echo $row->descr; ?>
			</td>
			<td>
				<?php echo $approve; ?>
			</td>
			<td>
				<input type="text" name="order[<?php echo $row->imageid; ?>]" size="5" value="<?php echo $row->orderby; ?>" <?php echo $disabled; ?> class="text_area" style="text-align:center;" />
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</table>
</div>

<input type="hidden" name="option" value="com_easygallery" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="images" />
</form>
