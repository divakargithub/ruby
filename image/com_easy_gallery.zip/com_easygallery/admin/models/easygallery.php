<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport('joomla.application.component.model');

class EasygalleryModelEasygallery extends JModel {
    function __construct() {
		parent::__construct();
    }	

	function _buildQuery() {
		$query = "SELECT * FROM #__components WHERE admin_menu_link LIKE 'option=com_easygallery%' AND parent != '' ORDER BY id";

		return $query;
	}

	function getData() {		
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data )) {
			$query = $this->_buildQuery();
			$this->_data = $this->_getList( $query );
		}

		return $this->_data;
	}
}
?>