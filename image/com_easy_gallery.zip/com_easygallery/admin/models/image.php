<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

class EasygalleryModelImage extends JModel
{

	function __construct() {
		parent::__construct();

		$array = JRequest::getVar('imageid',  0, '', 'array');
		$this->setImageId((int)$array[0]);
	}

	function setImageId($imageid) {
		// Set id and wipe data
		$this->_imageid	= $imageid;
		$this->_data = null;
	}

	function &getData()	{
		// Load the data
		if (empty( $this->_data )) {
			$query = ' SELECT * FROM #__easygallery_images WHERE imageid = '.$this->_imageid;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}

		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->imageid = 0;
			$this->_data->image = null;
		}

		return $this->_data;
	}

	function store() {
		$row =& $this->getTable('Images');

		$data = JRequest::get('post');

		$files = JRequest::get('files');	

		if (!empty($files['image_data']['name'])) {

			$error_upload = false;

			jimport('joomla.filesystem.file'); 
			$image_data = $files['image_data'];
			
			$image_data['name'] = JFile::makeSafe($image_data['name']);

			if (isset($image_data['name'])) {
				$filepath = JPath::clean(COM_EASYGALLERY_IMAGE_BASE.DS.strtolower($image_data['name']));
			}

			if (JFile::exists($filepath)) {
				$this->setError('Error. File already exists');
				$error_upload = true;
			} elseif (!JFile::upload($image_data['tmp_name'], $filepath)) {
				$this->setError('Error. Unable to upload file');
				$error_upload = true;
			}

			list($data['image_x'], $data['image_y']) = @getimagesize($filepath);
			$data['image_size'] = @filesize($filepath);
			$data['image_path'] = $filepath;
			$data['filename'] = basename($filepath);

		} elseif (empty($data['imageid'])) {
			$this->setError('Please select an image.');
			return false;			
		}

		$data['approve'] = (!empty($data['approve'])) ? "Y" : "N";

		// Bind the form fields to the hello table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Make sure the hello record is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the web link table to the database
		if (!$row->store()) {
			$this->setError($row->getErrorMsg());
			return false;
		}

		return $row->imageid;
	}

	function delete() {
		$imageids = JRequest::getVar( 'cid', array(0), 'post', 'array' );

		$row =& $this->getTable('Images');

		if (count( $imageids )) {
			foreach($imageids as $imageid) {
				if (!$row->delete( $imageid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
				}
			}
		}
		return true;
	}

}