<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

class EasygalleryModelImages extends JModel {

	var $_data;

	function _buildQuery()	{
		$query = ' SELECT * FROM #__easygallery_images ORDER BY orderby ';
		return $query;
	}

	function getData() {
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data )) {
			$query = $this->_buildQuery();
			$this->_data = $this->_getList($query);
		}
		return $this->_data;
	}

	function approve($cid, $publish = 1, $task = 'publish') {
		JArrayHelper::toInteger($cid);
		$cids = implode(',', $cid);

		$column = 'approv';
		$query = "UPDATE #__easygallery_images SET approve = ".(((int) $publish) ? '"Y"' : '"N"') ." WHERE imageid IN (".$cids.")";

		$this->_db->setQuery($query);
		if(!$this->_db->query()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		return count($cid);
	}

	function saveorder($orderby) {
		if (!empty($orderby)) {
			foreach ($orderby as $k => $v) {
				$query = "UPDATE #__easygallery_images SET orderby = '$v' WHERE imageid = '$k'";

				$this->_db->setQuery($query);
				if(!$this->_db->query()) {
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
		}

		return;
	}
}