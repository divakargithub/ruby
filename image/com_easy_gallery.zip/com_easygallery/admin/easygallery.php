<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
 * Define constants for all pages
 */
define( 'COM_EASYGALLERY_DIR', 'images'.DS.'easygallery'.DS);
define( 'COM_EASYGALLERY_BASE', JPATH_ROOT.DS.COM_EASYGALLERY_DIR );
define( 'COM_EASYGALLERY_BASEURL', JURI::root().str_replace( DS, '/', COM_EASYGALLERY_DIR ));

define( 'COM_EASYGALLERY_IMAGE_DIR', COM_EASYGALLERY_DIR.'images'.DS );
define( 'COM_EASYGALLERY_IMAGE_BASE', JPATH_ROOT.DS.COM_EASYGALLERY_IMAGE_DIR.DS );
define( 'COM_EASYGALLERY_IMAGE_BASEURL', JURI::root().str_replace( DS, '/', COM_EASYGALLERY_IMAGE_DIR ));

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';

// Require the base controller
require_once JPATH_COMPONENT.DS.'helpers'.DS.'easygallery.php';

// Initialize the controller

// Require specific controller if requested
if($controller = JRequest::getCmd('controller', 'control'))
{
  $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';

  if(file_exists($path))
  {
    require_once $path;
  }
  else
  {
	require_once JPATH_COMPONENT.DS.'controllers'.DS.'images.php';
    $controller = 'images';
	require_once JPATH_COMPONENT.DS.'controller.php';
  }
}

$classname	= 'EasygalleryController'.$controller;

$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getCmd('task'));
$controller->redirect();
?>