<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// No direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Easygallery Images Controller
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class EasygalleryControllerImages extends EasygalleryController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

	    // Set view
		JRequest::setVar('view', 'images');

		// Register Extra tasks
		$this->registerTask('new' , 'edit');
		$this->registerTask('apply', 'save');
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar('view', 'image');
		JRequest::setVar('layout', 'form');
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('image');

		if ($imageid = $model->store($post)) {
			$msg = JText::_('Image Saved!');
			$link = 'index.php?option=com_easygallery&controller=images	';
		} else {
			$msg = (($model->getError()) ? (JText::_($model->getError())) :  (JText::_('Error saving!')));
			$link = 'index.php?option=com_easygallery&controller=images';
		}

		// Check the table in so it can be edited.... we are done with it anyway
		
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('image');
		if(!$model->delete()) {
			$msg = JText::_( 'Error: One or More Images Could not be Deleted' );
		} else {
			$msg = JText::_( 'Image(s) Deleted' );
		}

		$this->setRedirect( 'index.php?option=com_easygallery&controller=images', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'Operation Cancelled' );
		$this->setRedirect( 'index.php?option=com_easygallery&controller=images', $msg );
	}

	function approve()
	{
		// Initialize variables
		$cid = JRequest::getVar('cid', array(), 'post', 'array');

		$task = JRequest::getCmd('task');
		$publish = ($task == 'approve');

		if(empty($cid)) {
			$this->setRedirect('index.php?option=com_easygallery&controller=images', JText::_('No image selected'));
			$this->redirect();
		}

		$model = $this->getModel('images');
		if($count = $model->approve($cid, $publish)) {
			if($count != 1) {
				$msg = JText::sprintf($publish ? '%d images were approved.' : '%d images were rejected', $count);
			} else {
				$msg = JText::_($publish ? 'Image was approved' : 'Image was rejected');
			}
			$this->setRedirect('index.php?option=com_easygallery&controller=images', $msg);
		} else {
			$msg = JText::_('There was an error approving or rejecting items.');
			$this->setRedirect('index.php?option=com_easygallery&controller=images', $msg, 'error');
		}

		return;
	}

	function reject()
	{
		$this->approve();
	}

	function saveorder()
	{
		$orderby = JRequest::getVar('order', array(), 'post', 'array');
		if(empty($orderby)) {
			$this->setRedirect('index.php?option=com_easygallery&controller=images', JText::_('No image to reorder'));
			$this->redirect();
		}

		$model = $this->getModel('images');

		$model->saveorder($orderby);

		$this->setRedirect('index.php?option=com_easygallery&controller=images', JText::_('New ordering was saved successfully.'));
		$this->redirect();		 
	}
}