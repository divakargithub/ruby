<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.filter.input');

class TableImages extends JTable {

	/**	Primary Key */
	var $imageid = null;

	/** @var int */
	var $id = null;
	/** @var string */
	var $image_path = null;
	/** @var string */
	var $image_type = null;
	/** @var int */
	var $image_x = null;
	/** @var int */
	var $image_y = null;
	/** @var int */
	var $image_size = null;
	/** @var string */
	var $filename = null;
	/** @var int */
	var $date = null;
	/** @var string */
	var $alt = null;
	/** @var string */
	var $descr = null;
	/** @var char */
	var $approve = null;
	/** @var int */
	var $orderby = null;
	/** @var string */
	var $md5 = null;

	function __construct(& $db) {
		parent::__construct('#__easygallery_images', 'imageid', $db);
	}

	function check() {
		return true;
	}
}
?>