<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
/**
 * Easygallery Component Easygallery Model
 *
 * @author      notwebdesign
 * @package		Joomla
 * @subpackage	EasyGallery
 * @since 1.5
 */

class EasygalleryModelEasygallery extends JModel {
    /**
	 * Constructor
	 */
	function __construct() {
		parent::__construct();
    }

	function getImageData($imageid = 0) {
		if (empty($imageid)) {
			return;
		}

		$db =& JFactory::getDBO();

		$query = "SELECT * FROM #__easygallery_images WHERE imageid = '$imageid' AND approve = 'Y' ORDER BY orderby ";
		$db->setQuery($query);
		$image_data = $db->loadResult();

		return $image_data;
	}

	function getImages() {
		$db =& JFactory::getDBO();

		$query = "SELECT * FROM #__easygallery_images WHERE approve = 'Y' ORDER BY orderby ";
		$db->setQuery($query);
		$images = $db->loadAssocList();

		return $images;
	}
}
?>