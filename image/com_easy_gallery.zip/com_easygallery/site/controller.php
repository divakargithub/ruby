<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * Easygallery Component Controller
 */
class EasygalleryController extends JController {
	function display() {
        // Make sure we have a default view
        if( !JRequest::getVar( 'view' )) {
		    JRequest::setVar('view', 'easygallery' );
        }
		parent::display();
	}
}
?>