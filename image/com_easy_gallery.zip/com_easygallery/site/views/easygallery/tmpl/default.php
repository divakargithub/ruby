<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php echo $this->params->get('top_text'); ?>
<?php 
$thumb_count = ($this->params->get('thumb_count') ? $this->params->get('thumb_count') : 7); 
$thumb_width = ($this->params->get('thumb_width') ? $this->params->get('thumb_width') : 40); 
$thumb_height = ($this->params->get('thumb_height') ? $this->params->get('thumb_height') : 70); 
$width = ($this->params->get('width') ? $this->params->get('width') : 300); 
$height = ($this->params->get('height') ? $this->params->get('height') : 300); 

?>
<br />

<link href="<?php echo COM_EASYGALLERY_BASEURL; ?>/gallery/css/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?php echo COM_EASYGALLERY_BASEURL; ?>/gallery/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo COM_EASYGALLERY_BASEURL; ?>/gallery/js/carousel.js"></script>

<script type="text/javascript">
	var cur = 0;
	var max=1;
	function show_img (id) {
		var small = document.getElementById("small_img_"+id);
		if (small) {
			var big = document.getElementById("main_img");
			if (big) {
				big.src = small.src;
				big.alt = small.alt;
			}
		}
		var descr = document.getElementById("gallery_descr_"+id);
		if (descr) {
			var big_descr = document.getElementById("gallery_descr_main");
			if (big_descr) {
				big_descr.innerHTML = descr.innerHTML;
			}
		}
		cur = id;
	}

	function show_next() {
		var curr = ((cur < max - 1) ? (cur + 1) : 0);
		show_img(curr);
	}

	function show_prev() {
		var curr = ((cur > 0) ? (cur- 1) : (max - 1));
		show_img(curr);
	}
</script>

<div class="gallery">
	<div class="gallery_1">
		<div class="gallery_1_1">
			<input type="image" value="" class="image_prev" onclick="javascript:show_prev()" />
		</div>
		<div class="gallery_1_2">
			<img src="" alt="" width="<?php echo $width; ?>" height="<?php echo $height; ?>" id="main_img" />
			<div class="gallery_descr_main" id="gallery_descr_main" ></div>
		</div>
		<div class="gallery_1_3">
			<input type="image" value="" class="image_next" onclick="javascript:show_next()" />
		</div>
	</div>
	<div class="gallery_2">
		<div class="gallery_2_1">
			<a href="#" class="prev" ></a>
		</div>
		<div class="gallery_2_2">
			<div class="carousel">
				<ul>
<?php

if (!empty($this->images)) {
	$i = 0;
	foreach ($this->images as $k => $v) {
?>
					<li><a href="javascript:void(0)" onclick="javascript:show_img(<?php echo $i;?>)" ><img id="small_img_<?php echo $i;?>" src="<?php echo COM_EASYGALLERY_IMAGE_BASEURL . $v['filename'];?>" width="<?php echo $thumb_width; ?>" height="<?php echo $thumb_height; ?>" alt="<?php echo $v['alt'];?>" /></a><div class="gallery_descr" id="gallery_descr_<?php echo $i;?>"><?php echo $v['descr'];?></div></li>
<?php
		$i++;
	}
}
?>
				</ul>
			</div>
		</div>
		<div class="gallery_2_3">
			<a href="#" class="next" /></a>
		</div>
	</div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery(".carousel").jCarouselLite({
			btnNext: ".next",
			btnPrev: ".prev",
			visible: <?php echo min($i, $thumb_count);?>,
			circular: true
		});
	});
	show_img(0);
	max=<?php echo $i; ?>;
</script>

<br />
<?php echo $this->params->get('bottom_text'); ?>