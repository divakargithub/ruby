<?php
/**
 * @package Easygallery for Joomla! 1.5
 * @version $Id: 1.0
 * @author Turnkeye.com
 * @copyright (C) 2010 Turnkeye.com
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

define( 'COM_EASYGALLERY_DIR', 'images'.DS.'easygallery');
define( 'COM_EASYGALLERY_BASE', JPATH_ROOT.DS.COM_EASYGALLERY_DIR );
define( 'COM_EASYGALLERY_BASEURL', JURI::root().'components/com_easygallery');

define( 'COM_EASYGALLERY_IMAGE_DIR', COM_EASYGALLERY_DIR.DS.'images'.DS );
define( 'COM_EASYGALLERY_IMAGE_BASE', JPATH_ROOT.DS.COM_EASYGALLERY_IMAGE_DIR );
define( 'COM_EASYGALLERY_IMAGE_BASEURL', JURI::root().str_replace( DS, '/', COM_EASYGALLERY_IMAGE_DIR ));

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';

// Initialize the controller
$controller = new EasygalleryController();
$controller->execute( null );

// Redirect if set by the controller
$controller->redirect();
?>